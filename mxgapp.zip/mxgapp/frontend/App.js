// In App.js in a new project

import * as React from 'react';
import { useContext } from 'react';
import { View, Text } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import HomeScreen from './Src';
import PerkScreen from './Src/Screens/PerkScreen';
import ProfileScreen from './Src/Screens/profile';
import MagazineScreen from './Src/Screens/magazineScreen';
import NotificationScreen from './Src/Screens/noitfication';
import VideoScreen from './Src/Screens/videoScreen';
import ResourceScreen from './Src/Screens/ResourceScreen';
import ArticleScreen from './Src/Screens/article';
import CalenderScreen from './Src/Screens/CalenderScreen';
import LoginScreen from './Src/Screens/LoginScreen';
import SignupScreen from './Src/Screens/SignUpScreen';
import VidScreen from './Src/Screens/VidScreen';
import AuthContextProvider, { AuthContext } from './store/auth-context';
import Ionicons from '@expo/vector-icons/Ionicons';


import { Colors } from './Src/constants/styles';


const Stack = createNativeStackNavigator();
const Tab = createBottomTabNavigator();

function MyTabs() {
  return (
    <Tab.Navigator screenOptions={{
      headerShown: false,
      tabBarShown: false,
      tabBarStyle: { backgroundColor: 'black'},
      tabBarActiveTintColor: '#87CEEB',
      tabBarInactiveTintColor: '#fff',

    }}>
      <Tab.Screen name="Home" component={HomeScreen} options={{
          headerShown: false,
          tabBarIcon: ({color, size}) => (
            <Ionicons name='home-outline' color={color} size={size} />
          )
          }}/>
          <Tab.Screen name="Bookmark" component={HomeScreen} options={{
          headerShown: false,
          tabBarIcon: ({color, size}) => (
            <Ionicons name='bookmark-outline' color={color} size={size} />
          )
          }}/>
          <Tab.Screen name="wallet" component={HomeScreen} options={{
          headerShown: false,
          tabBarIcon: ({color, size}) => (
            <Ionicons name='wallet-outline' color={color} size={size} />
          )
          }}/>
          <Tab.Screen name="Chat" component={HomeScreen} options={{
          headerShown: false,
          tabBarIcon: ({color, size}) => (
            <Ionicons name='chatbubbles-outline' color={color} size={size} />
          )
          }}/>
          <Tab.Screen name="Profile" component={ProfileScreen} options={{
          headerShown: false,
          tabBarIcon: ({color, size}) => (
            <Ionicons name='person-circle-outline' color={color} size={size} />
          )
          }}/>
    </Tab.Navigator>
  );
}
function AuthStack() {
  
  return (
    <Stack.Navigator
       options={{
        headerShown: false,
      }}
    >
   <Stack.Screen name="Login" component={LoginScreen} options={{
        headerShown: false,
        
        }} />
      <Stack.Screen name="Signup" component={SignupScreen} options={{
        headerShown: false
        }}/>
      
    </Stack.Navigator>
  );
}
function AuthenticatedStack() {
  return (
    <Stack.Navigator>
    <Stack.Screen name="but" component={MyTabs} options={{
        headerShown: false,
        }}/>
      <Stack.Screen name="HomeScreen" component={HomeScreen} options={{
        headerShown: false
        }}/>
      <Stack.Screen name="PerkScreen" component={PerkScreen} options={{
        headerShown: false
        }} />
      <Stack.Screen name="ProfileScreen" component={ProfileScreen} options={{
        headerShown: false
        }} />
          <Stack.Screen name="MagazineScreen" component={MagazineScreen} options={{
        headerShown: false
        }} />
        <Stack.Screen name="NotificationScreen" component={NotificationScreen} options={{
        headerShown: false
        }} />
         <Stack.Screen name="VideoScreen" component={VideoScreen} options={{
        headerShown: false
        }} />
        <Stack.Screen name="ResourceScreen" component={ResourceScreen} options={{
        headerShown: false
        }} />
         <Stack.Screen name="ArticleScreen" component={ArticleScreen} options={{
        headerShown: false
        }} />
         <Stack.Screen name="CalenderScreen" component={CalenderScreen} options={{
        headerShown: false
        }} />
          <Stack.Screen name="VidScreen" component={VidScreen} options={{
        headerShown: false
        }} />
    </Stack.Navigator>
  );
}
function Navigation() {
  const authCtx = useContext(AuthContext);
  return (
    <NavigationContainer>
   {!authCtx.isAuthenticated && <AuthStack />}
      {authCtx.isAuthenticated && <AuthenticatedStack />}
    </NavigationContainer>
  );
}
export default function App() {

  return (
    <>
    <AuthContextProvider>
    <Navigation />
   
      </AuthContextProvider>
    </>
  );
}