import React, { memo } from 'react';

import { View, ScrollView, Image, Pressable, Text, StyleSheet, Style} from 'react-native';
import Event from './component/event';
import Ionicons from '@expo/vector-icons/Ionicons';
import SearchBar from '../Src/component/Search'

import Logo from '../Src/IMG/mxg.png';
import VideoCarousel from './component/CostomVideoCarousel';
import VideoSub from './Subcomponent/video';
import CarouselCom1 from './Subcomponent/CarouselCom';
import CarouselCom from './Subcomponent/Carousel';


const HomeScreen = ({ navigation }) => (
  <View style={{ backgroundColor: '#F5F5F5', marginTop: 30,}}>


    <View style={{flexDirection: 'row',
    marginTop: 20,
    marginLeft: 20,
    marginBottom: 10}}>
    <View style={{alignItems: 'flex-start',}}>
    <Image source={Logo} style={{width: 60,
    height: 39}} />
      </View>
    
      <View style={{flexDirection : 'row',
    marginLeft: '55%'}}>
      <View style={{width:40,height:40, alignItems:'center',justifyContent:'center',alignSelf:'center'}}>
      
            <Ionicons name="notifications-sharp" color="#530CEE" size={20} onPress={() => navigation.navigate('NotificationScreen')} />
      </View>
        <Pressable style={{alignItems:'center',justifyContent:'center',alignSelf:'center', marginLeft:10}} onPress={() => navigation.navigate('ProfileScreen')}>
      
            <Ionicons name="person-circle-outline" color="#530CEE" size={20}  onPress={() => navigation.navigate('ProfileScreen')}/>
      </Pressable>
    
      </View>
 </View>
 <ScrollView showsVerticalScrollIndicator={false} >
      <SearchBar />
      <VideoCarousel />
      <CarouselCom />
       <>
    <Text style={{ marginLeft: 15, fontSize: 16, fontWeight: 900, color: '#076CF2' }}> Quick link </Text>
    <View
      style={{
        flexDirection: 'row',
        marginTop: 3,
        marginLeft: 15,
        marginBottom: 20,
      }}>
       {/* onPress={() => navigation.navigate('PerkScreen')} */}
      <Pressable  onPress={() => navigation.navigate('PerkScreen')}>  
        <View
          style={{ backgroundColor: '#F0F0F0', margin: 20, borderRadius: 20 }}>
          <Ionicons name="bookmarks-sharp" style={{ margin: 30,
    color: '#04BCF0',}} size={20} />
        </View>
        <Text style={{textAlign: 'center', fontWeight: 900, fontSize: 10}}>MXG Perks</Text>
      </Pressable>
      <Pressable onPress={() => navigation.navigate('MagazineScreen')}>
        <View
          style={{ backgroundColor: '#F0F0F0', margin: 20, borderRadius: 20 }}>
          <Ionicons name="document-text-sharp" style={{ margin: 30,
    color: '#04BCF0',}} size={20} />
        </View>
        <Text style={{textAlign: 'center', fontWeight: 900, fontSize: 10}}>MXG Magazine</Text>
      </Pressable>
      <Pressable onPress={() => navigation.navigate('VideoScreen')}>
        <View
          style={{ backgroundColor: '#F0F0F0', margin: 20, borderRadius: 20 }}>
          <Ionicons name="videocam-sharp" style={{ margin: 30,
    color: '#04BCF0',}} size={20} />
        </View>
        <Text style={{textAlign: 'center', fontWeight: 900, fontSize: 10}}>Marketing Video</Text>
      </Pressable>
    </View>
    <View
      style={{
        flexDirection: 'row',
        marginTop: 5,
        marginLeft: 15,
        marginBottom: 50,
      }}>
      {/* onPress={() => navigation.navigate('Resources')} */}
      <Pressable onPress={() => navigation.navigate('ResourceScreen')}>
        <View style={{ backgroundColor: '#F0F0F0',
    margin: 20,
    borderRadius: 20,}}>
          <Ionicons name="videocam-sharp" style={{ margin: 30,
    color: '#04BCF0',}} size={20} />
        </View>
        <Text style={{textAlign: 'center', fontWeight: 900, fontSize: 10}}>Resource Video</Text>
      </Pressable>

      <View>
        <View style={{backgroundColor: '#F0F0F0',
    margin: 20,
    borderRadius: 20,}}>
          <Ionicons name="train-sharp" style={{ margin: 30,
    color: '#04BCF0',}} size={20} />
        </View>
        <Text style={{textAlign: 'center', fontWeight: 900, fontSize: 10}}>News</Text>
      </View>


      <Pressable onPress={() => navigation.navigate('CalenderScreen')}>
        <View style={{backgroundColor: '#F0F0F0',
    margin: 20,
    borderRadius: 20,}}>
          <Ionicons name="calendar-sharp" style={{ margin: 30,
    color: '#04BCF0',}} size={20} />
        </View>
        <Text style={{textAlign: 'center', fontWeight: 900, fontSize: 10}}>Calendar</Text>
      </Pressable>
    </View>
  </>
  <Text style={{ marginLeft: 20, fontSize: 16, color: '#530CEE', marginTop: 0, marginBottom: 10, fontWeight: 900 }}> Recommended training for you </Text>
  <CarouselCom />
      {/* <TrianingCarousel /> */}
      <CarouselCom1 />
      <Event />

 
    </ScrollView>
    </View>
);
export default HomeScreen;
