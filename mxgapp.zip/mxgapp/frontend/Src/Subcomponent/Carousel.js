import React, {useRef, useState} from 'react';
import { useNavigation } from '@react-navigation/native';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  ImageBackground,
  ScrollView,
  Pressable,
  Image
} from 'react-native';

import Ionicons from '@expo/vector-icons/Ionicons';



import virt2 from '../IMG/virt2.jpg'
import virt from '../IMG/virt.jpg'
import tea from '../IMG/TEACH.jpg'
import vid from '../../Videos/Vid1.mp4'

// import YoutubeIframe from 'react-native-youtube-iframe';

import { Video, ResizeMode } from 'expo-av';


const {width: windowWidth} = Dimensions.get('window');

export default function CarouselCom({data}) {
  const navigation = useNavigation()
  const video = React.useRef(null);
  const [status, setStatus] = React.useState({});
  return (
    <>
    <ScrollView horizontal showsHorizontalScrollIndicator={false} bounces={false} style={{marginBottom: 15,}}>
        {/* <View 
       style={{margin: 10, marginTop: 0}}>
        <Video
        ref={video}
        style={styles.video}
        source={{
          uri: 'https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4',
        }}
       videoStyle={{width: 200, height: 200}}
      Thumbnail={{uri: "https://i.imgur.com/Pz2WYAc.jpg"}}
        isLooping
        onPlaybackStatusUpdate={status => setStatus(() => status)}
      />
      </View> */}



     {/* <View>
     <Thumbnail url="vid" />
     </View> */}
        
        <Pressable onPress={()=> navigation.navigate('VidScreen')}
       style={{margin: 5, marginLeft: 20, marginTop: 0,  width: 160, height: 120,}} >
    <Image source={virt2} style={{ width: '100%', height: '100%', borderRadius: 5,}}/>
    <Text style={{color: 'white', marginTop: -50,marginLeft: 5, fontSize: 14, paddingTop: -70, fontWeight: 900}}> The Latest In MXG App
       </Text>
       <Ionicons name="heart-outline" color="#ffffff" size={20} style={{marginTop: -100, marginLeft: 10, alignSelf: 'flex-end', marginRight: 10}} />
   
        </Pressable>
        <View style={{margin: 5, marginTop: 0, width: 160, height: 120,}}>
        <Image source={virt} style={{ width: '100%', height: '100%', borderRadius: 5,}}/>
      <Text style={{color: 'white', marginTop: -50,marginLeft: 5, fontSize: 14, paddingTop: -70, fontWeight: 900}}> You Are What You Eat..
       </Text>
       <Ionicons name="heart-outline" color="#ffffff" size={20} style={{marginTop: -100, marginLeft: 10, alignSelf: 'flex-end', marginRight: 10}} />
   
        </View>
        <View 
       style={{margin: 5, marginTop: 0,  width: 160, height: 120,}} >
    <Image source={tea} style={{ width: '100%', height: '100%', borderRadius: 5,}}/>
    <Text style={{color: 'white', marginTop: -50,marginLeft: 5, fontSize: 14, paddingTop: -70, fontWeight: 900}}> good heart is good health
       </Text>
       <Ionicons name="heart-outline" color="#ffffff" size={20} style={{marginTop: -100, marginLeft: 10, alignSelf: 'flex-end', marginRight: 10}} />
   
        </View>
    </ScrollView>

    </>
  );
}

const styles = StyleSheet.create({
 
  video: {
    width: 220,
    height: 220,
    marginTop: 0,
    marginBottom: 0,
    borderRadius: 10,
    borderBottomEndRadius: 10
  },

});
