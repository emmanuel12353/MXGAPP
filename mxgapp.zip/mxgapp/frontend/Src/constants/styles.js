export const Colors = {
  primary100: '#ffffff',
  primary500: '#04BCF0',
  primary800: '#610440',
  error100: '#fcdcbf',
  error500: '#f37c13',
}