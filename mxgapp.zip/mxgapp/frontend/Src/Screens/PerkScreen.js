import React, { memo, useState } from 'react';
import { Text, StyleSheet, TouchableOpacity, View, Pressable,  ScrollView } from 'react-native';


import Ionicons from '@expo/vector-icons/Ionicons';

const PerkScreen = ({ navigation }) => {



  return (
    < ScrollView>
    <View style={{flexDirection: 'row', marginLeft: 10, marginTop: 50 }}>
    <Ionicons name="chevron-back-outline" color="#04BCF0" size={40} style={{marginTop: 10, marginLeft: 10}} onPress={() => navigation.goBack()} />
    <Text style={{marginTop: 15, marginLeft: 70, fontSize: 16, fontWeight: 900}}> Members Perk </Text>

    </View>
 <Pressable  style={{backgroundColor: 'white', marginLeft: 10, marginRight: 10, borderRadius: 20, marginTop: 20}}>
  <View style={{flexDirection: 'row', marginBottom: 50,}}>
  <Text style={{fontSize: 16, marginTop: 20, marginLeft: 20,}}> Basic </Text>
   <Text style={{fontSize: 16, marginTop: 20, marginLeft: '60%', color: '#04BCF0'}}> 20$ </Text>
  </View>
  <Pressable  style={{backgroundColor: '#04BCF0', borderRadius: 20, borderTopEndRadius: 0, borderTopStartRadius: 0, marginTop: 20}}>
  <Text style={{fontSize: 20, marginTop: 20, textAlign: 'center', marginBottom: 20, color: 'white', fontWeight: 900, }}> choose perk</Text>
</Pressable>
</Pressable>

 <Pressable  style={{backgroundColor: 'white', marginLeft: 10, marginRight: 10, borderRadius: 20, marginTop: 20}}>
  <View style={{flexDirection: 'row', marginBottom: 50,}}>
  <Text style={{fontSize: 16, marginTop: 20, marginLeft: 20, fontWeight: 900,}}> Plantinum </Text>
   <Text style={{fontSize: 16, marginTop: 20, marginLeft: '50%', color: '#04BCF0'}}> 50$ </Text>
  </View>
  <Pressable  style={{backgroundColor: '#04BCF0', borderRadius: 20, borderTopEndRadius: 0, borderTopStartRadius: 0, marginTop: 20}}>
  <Text style={{fontSize: 20, marginTop: 20, textAlign: 'center', marginBottom: 20, color: 'white', fontWeight: 900, }}> choose perk</Text>
</Pressable>
</Pressable>

 <Pressable  style={{backgroundColor: 'white', marginLeft: 10, marginRight: 10, borderRadius: 20, marginTop: 20}}>
  <View style={{flexDirection: 'row', marginBottom: 50,}}>
  <Text style={{fontSize: 18, marginTop: 20, marginLeft: 20, fontWeight: 900}}> Pro Business </Text>
   <Text style={{fontSize: 16, marginTop: 20, marginLeft: '50%', color: '#04BCF0'}}> 50$ </Text>
  </View>
  <Pressable  style={{backgroundColor: '#04BCF0', borderRadius: 20, borderTopEndRadius: 0, borderTopStartRadius: 0, marginTop: 20}}>
  <Text style={{fontSize: 18, marginTop: 20, textAlign: 'center', marginBottom: 20, color: 'white', fontWeight: 900, }}> choose perk</Text>
</Pressable>
</Pressable>


    </ ScrollView>
  );
};



export default PerkScreen;
