import React, { memo } from 'react';

import { View, ScrollView, Image, Pressable, Text, StyleSheet } from 'react-native';

import Ionicons from '@expo/vector-icons/Ionicons';

const NotificationScreen = ({ navigation }) => (
  <View style={{ backgroundColor: '#F5F5F5', marginTop: 10,}}>
    <View style={{flexDirection: 'row', marginLeft: 10, marginTop: 30 }}>
    <Ionicons name="chevron-back-outline" color="#04BCF0" size={30} style={{marginTop: 10, marginLeft: 10}} onPress={() => navigation.goBack()}/>
    <Text style={{marginTop: 15, marginLeft: '25%', fontSize: 16, fontWeight: 900}}>
     Notifications </Text>

     <Ionicons name="ellipsis-vertical-outline" color="#04BCF0" size={30} style={{marginTop: 10, marginLeft: '25%'}} onPress={() => navigation.navigate('HomeScreen')}/>
     
    </View>
    <View style={{flexDirection: 'row', marginLeft: '8%', padding: 10, marginTop: 30,}}>
    <View style={{backgroundColor: '#04BCF0', paddingTop: 10, paddingBottom: 10, paddingLeft: 30, paddingRight: 30, borderRadius: 10, margin: 5, }}>
     <Text style={{fontSize: 16, color: 'white'}}>All</Text>
    </View>
   <View style={{backgroundColor: '#C0C0C0', paddingTop: 10, paddingBottom: 10, paddingLeft: 30, paddingRight:  30, borderRadius: 10, margin: 5, }}>
     <Text style={{fontSize: 16, color: 'white'}}>Update</Text>
    </View>
    <View style={{backgroundColor: '#C0C0C0', paddingTop: 10, paddingBottom: 10, paddingLeft: 30, paddingRight: 30, borderRadius: 10,margin: 5, }}>
     <Text style={{fontSize: 16, color: 'white'}}>News</Text>
    
    </View>
    </View>
    <Text style={styles.quick}> Today </Text>
      <View style={{marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white'}}>
    <View style={styles.row}>
    <View style={{width: 50, height: 50, backgroundColor: '#E8E8E8', borderRadius: 50,}}>
    <Ionicons name="rose-sharp" color="#04BCF0" size={30} style={{marginTop: 10, marginLeft: '15%'}} /> 
     
      </View>
    
      <View style={styles.row2}>
      <View> 
      <Text style={{fontSize: 14, fontWeight: 700, marginRight: 10, color: '#E8E8E8', marginLeft: 10,}}>company name</Text>
      </View>
     
      <View style={ {flexDirection: 'row', marginTop: 30,}}> 
    
      <Text style={{marginTop: 10, marginLeft: 10, fontSize: 10, color: '#E8E8E8',}}>Sunday may 8 2024 || </Text>
       
      </View>
    
      </View>
 </View>
 
  </View>
  <View style={{marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white'}}>
    <View style={styles.row}>
    <View style={{width: 50, height: 50, backgroundColor: '#E8E8E8', borderRadius: 50,}}>
    <Ionicons name="rose-sharp" color="#04BCF0" size={30} style={{marginTop: 10, marginLeft: '15%'}} /> 
     
      </View>
    
      <View style={styles.row2}>
      <View> 
      <Text style={{fontSize: 14, fontWeight: 700, marginRight: 10, color: '#E8E8E8', marginLeft: 10,}}>company name</Text>
      </View>
     
      <View style={ {flexDirection: 'row', marginTop: 30,}}> 
    
      <Text style={{marginTop: 10, marginLeft: 10, fontSize: 10, color: '#E8E8E8',}}>Sunday may 8 2024 || </Text>
       
      </View>
    
      </View>
 </View>
 
  </View>

    </View>
);
export default NotificationScreen;
const styles = StyleSheet.create({
    row: {
       flexDirection: 'row',
       marginTop: 40,
       marginLeft: 10,
       marginBottom: 30
     },
     img: {
       width: 100,
     },
     quick: {
       marginLeft: 15,
       fontSize: 18,
       marginBottom: 20,
       fontWeight: 900
     },
    
   });
   
