import React, { memo, useState } from 'react';
import { Text, StyleSheet, TouchableOpacity, View, Pressable,  ScrollView, Image } from 'react-native';

import SearchBar from '../component/Search';

import Ionicons from '@expo/vector-icons/Ionicons';
import Logo from '../IMG/mxg.png';
import Img1 from '../../Videos/img1.jpg';
import Img2 from '../../Videos/img3.jpg';
import Img3 from '../../Videos/img3.jpg';
import Img4 from '../../Videos/img4.jpg';



import virt2 from '../IMG/virt2.jpg'
import virt from '../IMG/virt.jpg'
import tea from '../IMG/TEACH.jpg'
import vid from '../../Videos/Vid1.mp4'
const ResourceScreen = ({ navigation }) => {



  return (
    < ScrollView>
    <View style={{flexDirection: 'row', marginLeft: 10, marginTop: 30 }}>
    <Ionicons name="chevron-back-outline" color="#04BCF0" size={30} style={{marginTop: 10, marginLeft: 10}} onPress={() => navigation.goBack()}/>
    <Text style={{marginTop: 15, marginLeft: '15%', fontSize: 16}}>
     Members Resources </Text>

    </View>

    <View style= {{marginBottom: 30, }} >
   <Text  style={{fontSize: 40, marginLeft: 10, marginTop: 20,}}>   
   Best Resources for your <Text style={{color: '#04BCF0' }}>Business</Text>
   </Text>
    <Text  style={{fontSize: 14, marginLeft: 15, marginTop: 2,}}>   
   Best Resources to help your Businesses
   </Text>
    </View>
    
    <SearchBar />
    <View style={{flexDirection: 'row', marginLeft: 5, padding: 10,}}>
    <View style={{backgroundColor: '#04BCF0', paddingTop: 10, paddingBottom: 10, paddingLeft: 20, paddingRight: 20, borderRadius: 10, margin: 5, }}>
     <Text style={{fontSize: 16, color: 'white'}}>All</Text>
    </View>
   <View style={{backgroundColor: '#E8E8E8', paddingTop: 10, paddingBottom: 10, paddingLeft: 20, paddingRight: 20, borderRadius: 10, margin: 5, }}>
     <Text style={{fontSize: 16, color: 'white'}}>Training</Text>
    </View>
    <View style={{backgroundColor: '#E8E8E8', paddingTop: 10, paddingBottom: 10, paddingLeft: 20, paddingRight: 20, borderRadius: 10,margin: 5, }}>
     <Text style={{fontSize: 16, color: 'white'}}>Form</Text>
    </View>
    <View style={{backgroundColor: '#E8E8E8', paddingTop: 10, paddingBottom: 10, paddingLeft: 20, paddingRight: 20, borderRadius: 10, margin: 5, }}>
     <Text style={{fontSize: 16, color: 'white'}}>Video</Text>
    </View>
    </View>

       <View style={{marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white'}}>
    <View style={styles.row}>
    <View style={styles.row1}>
    <Image source={virt} style={styles.img}/>
      </View>
    
      <View style={styles.row2}>
      <View> 
      <Text style={{fontSize: 14, fontWeight: 700, marginRight: 10}}>5 marketing tips you need to know</Text>
      </View>
       <View style={ {flexDirection: 'row',}}> 
      <Ionicons name="code-download-sharp" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: 10}} /> 
      <Text style={{marginTop: 10, marginLeft: 10, fontSize: 15}}>The roof top </Text>
      </View>
      <View style={ {flexDirection: 'row', marginTop: 30,}}> 
    
      <Text style={{marginTop: 10, marginLeft: 5, fontSize: 15, color: '#510FE4',}}>Sunday may 8 2024 || </Text>
       <Ionicons name="share-social-outline" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: '10%'}} /> 
        <Ionicons name="heart-outline" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: 10}} />
      </View>
    
      </View>
 </View>
  </View>

  
<View style={{marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white'}}>
<View style={styles.row}>
<View style={styles.row1}>
<Image source={virt2} style={styles.img}/>
  </View>

  <View style={styles.row2}>
  <View> 
  <Text style={{fontSize: 14, fontWeight: 700, marginRight: 10, marginTop: 10}}>5 marketing tips you need to know</Text>
  </View>
   <View style={ {flexDirection: 'row',}}> 
  <Ionicons name="code-download-sharp" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: 10}} /> 
  <Text style={{marginTop: 10, marginLeft: 10, fontSize: 15}}>The roof top </Text>
  </View>
  <View style={ {flexDirection: 'row', marginTop: 20,}}> 

  <Text style={{marginTop: 10, marginLeft: 5, fontSize: 15, color: '#510FE4',}}>Sunday may 8 2024 || </Text>
   <Ionicons name="share-social-outline" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: '10%'}} /> 
    <Ionicons name="heart-outline" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: 10}} />
  </View>

  </View>
</View>
</View>


  
   <View style={{marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white'}}>
    <View style={styles.row}>
    <View style={styles.row1}>
    <Image source={tea} style={styles.img}/>
      </View>
    
      <View style={styles.row2}>
      <View> 
      <Text style={{fontSize: 18, fontWeight: 700, marginRight: 10}}>Lorem ipsum dolor sit amet,</Text>
      </View>
       <View style={ {flexDirection: 'row',}}> 
      <Ionicons name="code-download-sharp" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: 10}} /> 
      <Text style={{marginTop: 10, marginLeft: 10, fontSize: 15}}>The roof top </Text>
      </View>
      <View style={ {flexDirection: 'row', marginTop: 30,}}> 
    
      <Text style={{marginTop: 10, marginLeft: 5, fontSize: 15, color: '#510FE4',}}>Sunday may 8 2024 || </Text>
       <Ionicons name="share-social-outline" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: '10%'}} /> 
        <Ionicons name="heart-outline" color="#510FE4" size={20} style={{marginTop: 10, marginLeft: 10}} />
      </View> 
    
      </View>
 </View>
  </View>
     <Text  style={{fontSize: 16,fontWeight: 900, marginLeft: 15, marginTop: 20, marginRight: 20,}}>   
   Recommended tools for you</Text>

 <View style={{flexDirection:'row', marginLeft: 10, marginTop: 20,}}>
      <Image source={Img1}  style={{width: 185, height: 150, margin:3, borderRadius: 10}}/>
      <Image source={Img2}  style={{width: 185, height: 150, margin:3, borderRadius: 10}}/>

    </View>
    </ ScrollView>
  );
};

export default memo(ResourceScreen);

const styles = StyleSheet.create({

  row: {
    flexDirection: 'row',
    marginTop: 0,
    marginLeft: 10,
    marginBottom: 0
  },
  img: {
    width: 130,
    height: 110,
    borderRadius: 10
  },
  quick: {
    marginLeft: 15,
    fontSize: 25
  },
});
