import React, { memo, useContext, useState } from 'react';

import { View, ScrollView, Image, Pressable, Text, StyleSheet, TextInput, Alert} from 'react-native';
import Img1 from '../../Videos/img1.jpg';
import Img2 from '../../Videos/img3.jpg';
import Img3 from '../../Videos/img3.jpg';
import Img4 from '../../Videos/img4.jpg';

import { Divider } from '@rneui/themed';
import{AuthContext} from '../../store/auth_context';

import Logo from '../IMG/mxg.png';
import Ionicons from '@expo/vector-icons/Ionicons';

const TemloginScreen = ({ navigation }) =>{ 
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [Authenticate, setIsAuthenticated] = useState('false')


  const loginCtx = useContext(AuthContext)

  function loginHandler() {
    loginCtx.login();
  }


 
  
  return (
  <View style={{ marginTop: 20,}}>
  <Image source={Logo}  style={{width: 131, height: 89, margin:3, borderRadius: 10, marginLeft: '40%', marginTop: '20%'}}/>
  
  {/* <Divider style={{width: '10%', }}
          inset={true} /> */}
   <Text style={{fontSize: 22, fontWeight: 900, marginLeft: 20, color: '#510FE4'}}> WELCOME</Text>
   <Text style={{fontSize: 22, fontWeight: 900, marginLeft: 20, color: 'black'}}> Kelvin</Text>

   <View style={{marginTop: '20%',}}>
   <Text style={{marginLeft: 20, fontWeight: 900,}}>password</Text>
   <TextInput label="Label" variant="standard" style={{backgroundColor: '#D3D3D3', marginLeft: 20, marginRight: 20, borderRadius: 10, padding: 15}} />
   </View>
   <Pressable style={{backgroundColor: '#510fe4', marginLeft: 20, marginRight: 20, borderRadius: 10, marginTop: '40%'}} onPress={()=> {loginHandler()}}>
    <Text style={{padding: 20, fontSize: 20, fontWeight: 900, textAlign: 'center', color: 'white'}}>Continue</Text>
   </Pressable>
 </View>
)
        }
export default (TemloginScreen);