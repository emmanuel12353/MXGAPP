import React, {useRef, useState } from 'react';

import { View, ScrollView, Image, Pressable, Text, StyleSheet } from 'react-native';
import Img1 from '../../Videos/img1.jpg';
import Img2 from '../../Videos/img3.jpg';
import Img3 from '../../Videos/img3.jpg';
import Img4 from '../../Videos/img4.jpg';

import Logo from '../IMG/mxg.png';

import { Video, ResizeMode } from 'expo-av';

import Ionicons from '@expo/vector-icons/Ionicons';

function VidScreen ({ navigation }) {
    const video = React.useRef(null);
    const [status, setStatus] = React.useState({});
    
    return (
    <ScrollView>
  <View style={{ backgroundColor: '#F5F5F5', marginTop: 10,}}>
    <View style={{flexDirection: 'row', marginLeft: 10, marginTop: 20 }}>
    <Ionicons name="chevron-back-outline" color="#510FE4" size={40} style={{marginTop: 10, marginLeft: 10}} onPress={() => navigation.goBack()}/>
    <Text style={{marginTop: 15, marginLeft: '15%', fontSize: 20}}>
     MXG Magazine </Text>

     <Ionicons name="ellipsis-vertical-outline" color="#510FE4" size={40} style={{marginTop: 10, marginLeft: '20%'}} onPress={() => navigation.navigate('HomeScreen')}/>
     
    </View>
   
        <View 
       style={{margin: 10, marginTop: 20, width: '100%'}}>
        <Video
        ref={video}
        style={styles.video}
        source={{
          uri: 'https://d23dyxeqlo5psv.cloudfront.net/big_buck_bunny.mp4',
        }}
       videoStyle={{width: 380, height: 200}}
       resizeMode={ResizeMode.COVER}
        isLooping
        onPlaybackStatusUpdate={status => setStatus(() => status)}
       muted={true}
       repeat={true}
       autoPlay={true}
   
      />
      </View>

 <View style= {{marginBottom: 30, }} >
 <View style= {{width: '90%' }} >
   <Text  style={{fontSize: 16,fontWeight: 900, marginLeft: 20, marginTop: 10, marginRight: 20, color: '#610440'}}>   
5 Marketing Tips Yur Need To Know To Grow Your Business</Text>
<Text  style={{fontSize: 12, marginLeft: 15, marginTop: 2, color: '#610440', fontWeight: 900}}>   
  The impact of virtual reality on our daily lives
   </Text>
   <View style={ {flexDirection: 'row', marginTop: 0,}}> 
       <Ionicons name="share-social-outline" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: 25}} /> 
        <Ionicons name="heart-outline" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: 20}} />
        <Ionicons name="bookmark-outline" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: 20}} />
      </View>

      <Text  style={{fontSize: 16, marginLeft: 15, marginTop: 30, color: '#610440', fontWeight: 900}}>   
      Discription   </Text>
</View>
</View>
</View>
    </ScrollView>
);
    }
export default VidScreen;
const styles = StyleSheet.create({
 
    video: {
      width: 380,
      height: 200,
      marginTop: 0,
      marginBottom: 0,
      marginRight: 20,
      borderRadius: 10,
      borderBottomEndRadius: 10,
      borderBottomLeftRadius: 10,
      borderBottomRightRadius: 10,
      borderBottomStartRadius: 10,

    },
  
  });
