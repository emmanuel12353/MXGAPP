import React, { memo, useState } from 'react';
import { Text, StyleSheet, TouchableOpacity, View, Pressable,  ScrollView, Image } from 'react-native';

import { TextInput, Divider } from "@react-native-material/core";
import SearchBar from '../component/Search';

import Ionicons from '@expo/vector-icons/Ionicons';
import Logo from '../IMG/mxg.png';
import Img1 from '../../Videos/img1.jpg';
import Img2 from '../../Videos/img3.jpg';
import Img3 from '../../Videos/img3.jpg';
import Img4 from '../../Videos/img4.jpg';


const CalenderScreen = ({ navigation }) => {



  return (
    < ScrollView>
    <View style={{flexDirection: 'row', marginLeft: 10, marginTop: 50 }}>
    <Ionicons name="chevron-back-outline" color="#04BCF0" size={30} style={{marginTop: 10, marginLeft: 10}} onPress={() => navigation.goBack()}/>
    <Text style={{marginTop: 15, marginLeft: '25%', fontSize: 20, fontWeight: 900}}>
    Calender </Text>

    </View>
    <Text style={{fontSize: 30, fontWeight: 900, marginLeft: 20, color: '#000000', marginTop: 20 }}>Get the latest update to <Text style={{color:'#04BCF0'}}>Event</Text> and <Text style={{color: '#04BCF0'}}>Meetings</Text></Text>
   
    <SearchBar />

        <View style={{flexDirection: 'row', marginLeft: 8, padding: 10, marginTop: 10,}}>
    <View style={{backgroundColor: '#04BCF0', paddingTop: 10, paddingBottom: 10, paddingLeft: 30, paddingRight: 30, borderRadius: 10, margin: 2, }}>
     <Text style={{fontSize: 14, color: 'white'}}>All</Text>
    </View>
   <View style={{backgroundColor: '#C0C0C0', paddingTop: 10, paddingBottom: 10, paddingLeft: 30, paddingRight:  30, borderRadius: 10, margin: 2, }}>
     <Text style={{fontSize: 14, color: 'white'}}>For you</Text>
    </View>
    <View style={{backgroundColor: '#C0C0C0', paddingTop: 10, paddingBottom: 10, paddingLeft: 30, paddingRight:  30, borderRadius: 10, margin: 2, }}>
     <Text style={{fontSize: 14, color: 'white'}}>online</Text>
    </View>
    <View style={{backgroundColor: '#C0C0C0', paddingTop: 10, paddingBottom: 10, paddingLeft: 30, paddingRight: 30, borderRadius: 10,margin: 2, }}>
     <Text style={{fontSize: 14, color: 'white'}}>Trending</Text>
    
    </View>
     </View>
    </ScrollView>
  )
}

export default CalenderScreen;

