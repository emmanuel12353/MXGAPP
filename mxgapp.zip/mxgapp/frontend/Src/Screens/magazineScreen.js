import React, { memo, useState } from 'react';
import { Text, StyleSheet, TouchableOpacity, View, Pressable,  ScrollView, Image } from 'react-native';

import SearchBar from '../component/Search';

import Ionicons from '@expo/vector-icons/Ionicons';
import Logo from '../IMG/mxg.png';

import Virt from '../IMG/virt.jpg'


const MagazineScreen = ({ navigation }) => {



  return (
    < ScrollView>
    <View style={{flexDirection: 'row', marginLeft: 10, marginTop: 30 }}>
    <Ionicons name="chevron-back-outline" color="#04BCF0" size={30} style={{marginTop: 20, marginLeft: 10}} onPress={() => navigation.goBack()}/>
    <Text style={{marginTop: 20, marginLeft: '25%', fontSize: 14, fontWeight: 900}}>
     MXG Magazine </Text>

    </View>

    
    <SearchBar />
    <View style={{flexDirection: 'row', marginLeft: 5, padding: 10,}}>
    <View style={{backgroundColor: '#04BCF0', paddingTop: 10, paddingBottom: 10, paddingLeft: 20, paddingRight: 20, borderRadius: 10, margin: 5, }}>
     <Text style={{fontSize: 16, color: 'white'}}>All</Text>
    </View>
   <View style={{backgroundColor: '#E8E8E8', paddingTop: 10, paddingBottom: 10, paddingLeft: 20, paddingRight: 20, borderRadius: 10, margin: 5, }}>
     <Text style={{fontSize: 16, color: '#A8A8A8'}}>Training</Text>
    </View>
    <View style={{backgroundColor: '#E8E8E8', paddingTop: 10, paddingBottom: 10, paddingLeft: 20, paddingRight: 20, borderRadius: 10,margin: 5, }}>
     <Text style={{fontSize: 16, color: '#A8A8A8'}}>Form</Text>
    </View>
    <View style={{backgroundColor: '#E8E8E8', paddingTop: 10, paddingBottom: 10, paddingLeft: 20, paddingRight: 20, borderRadius: 10, margin: 5, }}>
     <Text style={{fontSize: 16, color: '#A8A8A8'}}>Video</Text>
    </View>
    </View>
    <Text  style={{fontSize: 16,fontWeight: 900, marginLeft: 15, marginTop: 20, marginRight: 20, marginBottom: 10}}>   
   Recent Articles</Text>
       <Pressable style={{marginLeft: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white', marginRight: 10,}} onPress={() => navigation.navigate('ArticleScreen')}>
    <View style={styles.row}>
    <Image source={Virt} style={styles.img}/>
    
      <View style={styles.row2}>
      <View style={{flexDirection: 'row', marginBottom: 0,}}>
        <Pressable style={{}}>
        <Text style={{fontSize: 8, fontWeight: 900, marginTop: 5, marginBottom: 10, marginLeft: 5, marginRight: 10, backgroundColor: '#E8E8E8', borderRadius: 20, padding: 10,}}>
        Michel green
      </Text>
        </Pressable>

         <Pressable style={{}} onPress={() => navigation.navigate('ArticleScreen')}>
        <Text style={{fontSize: 8, fontWeight: 900, marginTop: 5, marginBottom: 10, marginLeft: 2, marginRight: 30, backgroundColor: '#E8E8E8', borderRadius: 20, padding: 10}}>
        Michel green
      </Text>
        </Pressable>
      </View>
      <View style={{ overflow:'hidden', marginRight: 10, paddingTop: 2, width: 250,}}> 
      <Text style={{fontSize: 16, fontWeight: 700, marginRight: 10, width: '100%'  }}>5 marketing tips you need to know </Text>
      </View>
       
      <View style={ {flexDirection: 'row', marginTop: 2,}}> 
    
      <Pressable style={{backgroundColor:'#3d3b3b',width:20,height:20,borderRadius:40/2,alignItems:'center',justifyContent:'center',alignSelf:'center', marginLeft:2}} onPress={() => navigation.navigate('ArticleScreen')}>
      <Ionicons name="person-sharp" color="#510FE4" size={10} />
      </Pressable>
      <Pressable style={{marginTop: 10, marginLeft: 10, }}>
      <Text style={{fontSize: 10, fontWeight: 900,}}>
        Michel green
      </Text>
      </Pressable>
    
      <View style={{flexDirection : 'row',
    marginLeft: '20%'}}>
      <View style={{width:40,height:40, alignItems:'center',justifyContent:'center',alignSelf:'center'}}>
      
      <Ionicons name="share-social-outline" color="#510FE4" size={14} />
      </View>
        <Pressable style={{width:40,height:40, alignItems:'center',justifyContent:'center',alignSelf:'center'}} >
      
            <Ionicons name="bookmark-outline" size={14} color="#510FE4"/>
      </Pressable>
    </View>
      </View>      
    
      </View>
 </View>
  </Pressable>

    
    

 

    </ ScrollView>
  );
};



export default MagazineScreen;


const styles = StyleSheet.create({

  row: {
    flexDirection: 'row',
    marginTop: 0,
    marginLeft: 10,
    marginBottom: 0
  },
  img: {
    width: 150,
    height: 150,
    borderRadius: 20
  },
  quick: {
    marginLeft: 15,
    fontSize: 25
  },
 
});
