import React, { memo, useState } from 'react';
import { Text, StyleSheet, TouchableOpacity, View, Pressable,  ScrollView, Image } from 'react-native';

import SearchBar from '../component/Search';

import Ionicons from '@expo/vector-icons/Ionicons';
import Logo from '../IMG/mxg.png';
import Img1 from '../../Videos/img1.jpg';
import Img2 from '../../Videos/img3.jpg';
import Img3 from '../../Videos/img3.jpg';
import profile from '../../Videos/profile2.png';


const ProfileScreen = ({ navigation }) => {

  return (
    < ScrollView>
    <Pressable style={{flexDirection: 'row', marginLeft: 10, marginTop: 30 }} onPress={() => navigation.navigate('HomeScreen')}>
    <Ionicons name="chevron-back-outline" color="#510FE4" size={40} style={{marginTop: 10, marginLeft: 10}} onPress={() => navigation.goBack()}/>
    <Text style={{marginTop: 15, marginLeft: '30%', fontSize: 16, fontWeight: 700,}}>
     Profile </Text>

    </Pressable>
  <View style={{marginTop: 30, alignItems:'center' ,justifyContent:'center',alignSelf:'center',}}>
  <View style={{backgroundColor:'black',width:150,height:150,borderRadius: 100, alignItems:'center' ,justifyContent:'center',alignSelf:'center', marginLeft:10,}}>
    <Image source={profile}  style={{width: 130, height: 130, borderRadius: 100,}}/>  
      </View>
      <Text style={{fontSize: 16, fontWeight: 900, marginTop: 10,}}>RICHARD SAMSON</Text>
      <Text style={{fontSize: 14, fontWeight: 900, marginTop: 2,}}>RICHARDSAMSON@GMAIL.COM</Text>
  </View>

   <View style={{marginLeft: 10, marginRight: 10, marginBottom: 3, borderRadius: 20, backgroundColor: 'white', marginTop: 30,}}>
    <View style={styles.row}>
    <View style={{}}>
    <Ionicons name="person-sharp" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '10%'}} /> 
     
      </View>
    
       
      <Text style={{fontSize: 19, fontWeight: 700, marginRight: 20, color: '#E8E8E8', marginLeft: 5, marginTop: 10,}}>My account</Text>
      <Ionicons name="chevron-forward-outline" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '35%'}} /> 
 </View>

 
 
  </View>

   <View style={{marginLeft: 10, marginRight: 10, marginBottom: 0, borderRadius: 20, backgroundColor: 'white', marginTop: 3,}}>
    <View style={styles.row}>
    <View style={{}}>
    <Ionicons name="language-sharp" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '10%'}} /> 
     
      </View>
    
       
      <Text style={{fontSize: 19, fontWeight: 700, marginRight: 20, color: '#E8E8E8', marginLeft: 5, marginTop: 10,}}>Language</Text>
      <Ionicons name="chevron-forward-outline" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '40%'}} /> 
 </View>

 
 
  </View>
  <View style={{marginLeft: 10, marginRight: 10, marginBottom: 3, borderRadius: 20, backgroundColor: 'white', marginTop: 3,}}>
    <View style={styles.row}>
    <View style={{}}>
    <Ionicons name="card-sharp" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '10%'}} /> 
     
      </View>
    
       
      <Text style={{fontSize: 19, fontWeight: 700, marginRight: 20, color: '#E8E8E8', marginLeft: 5, marginTop: 10,}}>
     payment method</Text>
      <Ionicons name="chevron-forward-outline" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '25%'}} /> 
 </View>

 
 
  </View>

  <View style={{marginLeft: 10, marginRight: 10, marginBottom: 0, borderRadius: 20, backgroundColor: 'white', marginTop: 3,}}>
    <View style={styles.row}>
    <View style={{}}>
    <Ionicons name="information-circle-sharp" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '10%'}} /> 
     
      </View>
    
       
      <Text style={{fontSize: 19, fontWeight: 700, marginRight: 20, color: '#E8E8E8', marginLeft: 5, marginTop: 10,}}>
      Help and support</Text>
      <Ionicons name="chevron-forward-outline" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '25%'}} /> 
 </View>

 
 
  </View>
  <View style={{marginLeft: 10, marginRight: 10, marginBottom: 3, borderRadius: 20, backgroundColor: 'white', marginTop: 3,}}>
    <View style={styles.row}>
    <View style={{}}>
    <Ionicons name="settings-sharp" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '10%'}} /> 
     
      </View>
    
       
      <Text style={{fontSize: 19, fontWeight: 700, marginRight: 20, color: '#E8E8E8', marginLeft: 5, marginTop: 10,}}>Settings</Text>
      <Ionicons name="chevron-forward-outline" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '45%'}} /> 
 </View>

 
 
  </View>
  <View style={{marginLeft: 10, marginRight: 10, marginBottom: 3, borderRadius: 20, backgroundColor: 'white', marginTop: 3,}}>
    <View style={styles.row}>
    <View style={{}}>
    <Ionicons name="settings-sharp" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '10%'}} /> 
     
      </View>
    
       
      <Text style={{fontSize: 19, fontWeight: 700, marginRight: 20, color: '#E8E8E8', marginLeft: 5, marginTop: 10,}}>about us</Text>
      <Ionicons name="chevron-forward-outline" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '45%'}} /> 
 </View>

 
 
  </View>
  <View style={{marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white', marginTop: 3,}}>
    <View style={styles.row}>
    <View style={{}}>
    <Ionicons name="log-out-sharp" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '10%'}} /> 
     
      </View>
    
       
      <Text style={{fontSize: 19, fontWeight: 700, marginRight: 20, color: '#E8E8E8', marginLeft: 5, marginTop: 10,}}>Logout</Text>
 </View>

 
 
  </View>



    </ ScrollView>
  );
};

export default ProfileScreen;

const styles = StyleSheet.create({

  row: {
    flexDirection: 'row',
    marginTop: 10,
    marginLeft: 10,
    marginBottom: 10
  },
  img: {
    width: 130,
  },
  quick: {
    marginLeft: 15,
    fontSize: 25
  },
});