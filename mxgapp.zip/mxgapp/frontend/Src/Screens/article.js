import React, { memo } from 'react';

import { View, ScrollView, Image, Pressable, Text, StyleSheet } from 'react-native';
import Img1 from '../../Videos/img1.jpg';
import Img2 from '../../Videos/img3.jpg';
import Img3 from '../../Videos/img3.jpg';
import Img4 from '../../Videos/img4.jpg';

import Logo from '../IMG/mxg.png';
import Ionicons from '@expo/vector-icons/Ionicons';

const ArticleScreen = ({ navigation }) => (
    <ScrollView>
  <View style={{ backgroundColor: '#F5F5F5', marginTop: 10,}}>
    <View style={{flexDirection: 'row', marginLeft: 10, marginTop: 50 }}>
    <Ionicons name="chevron-back-outline" color="#510FE4" size={40} style={{marginTop: 10, marginLeft: 10}} onPress={() => navigation.goBack()}/>
    <Text style={{marginTop: 15, marginLeft: '15%', fontSize: 20}}>
     MXG Magazine </Text>

     <Ionicons name="ellipsis-vertical-outline" color="#510FE4" size={40} style={{marginTop: 10, marginLeft: '20%'}} onPress={() => navigation.navigate('HomeScreen')}/>
     
    </View>
    <View style= {{marginBottom: 30, }} >
   <Text  style={{fontSize: 24,fontWeight: 900, marginLeft: 10, marginTop: 20, marginRight: 20,}}>   
   THE IMPACT OF VIRTUAL REALITY IN TECH</Text>
   <Text  style={{fontSize: 16, marginLeft: 15, marginTop: 2,}}>   
  The impact of virtual reality on our daily lives
   </Text>
    </View>
    <View style={{flexDirection: 'row',
    marginTop: 20,
    marginLeft: 10,
    marginBottom: 10}}>
  
    <Pressable style={{backgroundColor:'#3d3b3b',width:40,height:40,borderRadius:40/2,alignItems:'center',justifyContent:'center',alignSelf:'center', marginLeft:10}} onPress={() => navigation.navigate('LoginScreen')}>
      <Ionicons name="person-sharp" color="#510FE4" size={30} />
      </Pressable>
      <Pressable style={{marginTop: 10, marginLeft: 10, }}>
      <Text style={{fontSize: 12, fontWeight: 900,}}>
        Michel green
      </Text>
      </Pressable>
      <Pressable style={{marginTop: 0, marginLeft: 10, borderRadius: 20, backgroundColor: 'blue'}}>
      <Text style={{fontSize: 12, fontWeight: 900, marginBottom: 10, marginLeft: 30, marginRight: 30, marginTop: 10, color: 'white'}}>
       follow
      </Text>
      </Pressable>
    
      <View style={{flexDirection : 'row',
    marginLeft: '10%'}}>
      <View style={{width:40,height:40, alignItems:'center',justifyContent:'center',alignSelf:'center'}}>
      
            <Ionicons name="share-social-outline" color="#510FE4" size={20} />
      </View>
        <Pressable >
      
            <Ionicons name="bookmark-outline" size={30} color="#510FE4"/>
      </Pressable>
    
      </View>
 </View>
 <Image source={Img4} style={{ width: '90%', margin: 15, borderRadius: 10,}}/>
 <View style= {{marginBottom: 30, }} >
   <Text  style={{fontSize: 24,fontWeight: 900, marginLeft: 15, marginTop: 20, marginRight: 20,}}>   
   INTRO</Text>
   <Text  style={{fontSize: 14, marginLeft: 10, marginRight: 10,marginTop: 2, textAlign: 'justify'}}>   
   Virtual reality (VR) has emerged as a groundbreaking technology that is reshaping 
   the way we interact with digital content. By creating immersive and realistic virtual 
   environments, VR has opened up endless possibilities across various industries. In the realm 
   of technology, VR has made a significant impact, revolutionizing the way we experience entertainment, 
   ducation, training, and even healthcare. This article explores the transformative power of virtual reality 
   and its profound implications for the tech industry.</Text>
   <Text  style={{fontSize: 24,fontWeight: 900, marginLeft: 15, marginTop: 20, marginRight: 20,}}>   
   Design and Visualization:</Text>
   <Text  style={{fontSize: 14, marginLeft: 10, marginRight: 10,marginTop: 2, textAlign: 'justify'}}> 
Virtual reality has transformed the way we design and visualize products, buildings, and spaces. 
Architects, engineers, and product designers can now create virtual prototypes and walkthroughs, 
allowing stakeholders to experience and provide feedback before a physical product or structure is built. 
This not only saves time and resources but also enables more accurate and informed decision-making. VR technology 
has become an indispensable tool for design, enabling innovative and efficient workflows.
</Text>
<Text  style={{fontSize: 24,fontWeight: 900, marginLeft: 15, marginTop: 20, marginRight: 20,}}>   
Healthcare and Therapy: </Text>
<Text  style={{fontSize: 14, marginLeft: 10, marginRight: 10,marginTop: 2, textAlign: 'justify'}}> 
In the realm of healthcare, virtual reality is being utilized to enhance medical training, pain management, and therapy. VR simulations can replicate medical procedures, enabling doctors and students to practice complex surgeries and interventions. Additionally, VR is used for pain distraction during medical procedures and rehabilitation exercises. In mental health therapy, VR-based environments are proving effective in treating phobias, post-traumatic stress disorder (PTSD), and anxiety disorders. The immersive and controlled nature of VR enables patients to confront and overcome their fears in a safe and supportive environment.
   </Text>
    </View>
    </View>
    </ScrollView>
);
export default ArticleScreen;
