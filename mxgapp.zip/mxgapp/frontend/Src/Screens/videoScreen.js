import React, { memo } from 'react';

import { View, ScrollView, Image, Pressable, Text, StyleSheet } from 'react-native';
import Img1 from '../../Videos/img1.jpg';
import Img2 from '../../Videos/img3.jpg';
import Img3 from '../../Videos/img3.jpg';
import Img4 from '../../Videos/img4.jpg';

import Logo from '../IMG/mxg.png';
import Ionicons from '@expo/vector-icons/Ionicons';

const VideoScreen = ({ navigation }) => (
  <View style={{ backgroundColor: '#F5F5F5', marginTop: 20,}}>
    <View style={{flexDirection: 'row', marginLeft: 10, marginTop: 20 }}>
    <Ionicons name="chevron-back-outline" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: 10}} onPress={() => navigation.goBack()}/>
    <Text style={{marginTop: 15, marginLeft: '15%', fontSize: 16}}>
     Martketing Video </Text>

     <Ionicons name="ellipsis-vertical-outline" color="#510FE4" size={30} style={{marginTop: 10, marginLeft: '30%'}} onPress={() => navigation.navigate('HomeScreen')}/>
     
    </View>

    <View style={{flexDirection:'row', marginLeft: 10, marginTop: 20,}}>
      <Image source={Img1}  style={{width: 185, height: 150, margin:3, borderRadius: 10}}/>
      <Image source={Img2}  style={{width: 185, height: 150, margin:3, borderRadius: 10}}/>

    </View>
    <View style={{flexDirection:'row', marginLeft: 10, marginTop: 20,}}>
      <Image source={Img3}  style={{width: 185, height: 150, margin:3, borderRadius: 10}}/>
      <Image source={Img4}  style={{width: 185, height: 150, margin:3, borderRadius: 10}}/>

    </View>
    </View>
);
export default memo(VideoScreen);
