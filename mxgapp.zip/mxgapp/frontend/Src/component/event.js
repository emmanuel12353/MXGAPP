
import * as React from "react";
import {
 Text,
  View, 
 StyleSheet,
 SafeAreaView,
 ScrollView,
 Image,

} from "react-native";
import MaterialIcons from "@expo/vector-icons";

import Logo from '../IMG/mxg.png';
import Ionicons from '@expo/vector-icons/Ionicons';

import virt2 from '../IMG/virt2.jpg'
import virt from '../IMG/virt.jpg'
import tea from '../IMG/TEACH.jpg'

export default function Event ({ navigation }) {
  return (
     <SafeAreaView>
      <ScrollView style={styles.ScrollView}>
          <Text style={styles.quick}> Event for you </Text>
      <View style={{marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white'}}>
    <View style={styles.row}>
    <View style={styles.row1}>
    <Image source={virt} style={styles.img}/>
      </View>
    
      <View style={styles.row2}>
      <View style={{width: 200}}> 
      <Text style={{fontSize: 18, fontWeight: 900, marginLeft: 10,}}>Business fashion display</Text>
      </View>
       <View style={ {flexDirection: 'row',}}> 
      <Ionicons name="code-download-sharp" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: 10}} /> 
      <Text style={{marginTop: 10, marginLeft: 10, fontSize: 12}}>The roof top </Text>
      </View>
      <View style={ {flexDirection: 'row', marginTop: 10,}}> 
    
      <Text style={{marginTop: 10, marginLeft: 10, fontSize: 12, color: '#076CF2',}}>Sunday may 8 2024 || </Text>
       <Ionicons name="share-social-outline" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: '12%'}} /> 
        <Ionicons name="heart-outline" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: 10}} />
      </View>
    
      </View>
 </View>
  </View>

  
   <View style={{marginLeft: 10, marginRight: 10, marginBottom: 10, borderRadius: 20, backgroundColor: 'white'}}>
    <View style={styles.row}>
    <View style={styles.row1}>
    <Image source={tea} style={styles.img}/>
      </View>
    
      <View style={styles.row2}>
      <View style={{width: 200}}> 
      <Text style={{fontSize: 18, fontWeight: 900, marginLeft: 10}}>The roof top event</Text>
      </View>
       <View style={ {flexDirection: 'row',}}> 
      <Ionicons name="code-download-sharp" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: 10}} /> 
      <Text style={{marginTop: 10, marginLeft: 10, fontSize: 12}}>The roof top </Text>
      </View>
      <View style={ {flexDirection: 'row', marginTop: 30,}}> 
    
      <Text style={{marginTop: 10, marginLeft: 10, fontSize: 12, color: '#076CF2',}}>Sunday may 8 2024 || </Text>
       <Ionicons name="share-social-outline" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: '12%'}} /> 
        <Ionicons name="heart-outline" color="#076CF2" size={20} style={{marginTop: 10, marginLeft: 10}} />
      </View>
    
    
      </View>
 </View>
  </View>

 

        </ScrollView>
    </SafeAreaView>
  );
}
const styles = StyleSheet.create({
  ScrollView : {
        marginBottom: 50
  },
 row: {
    flexDirection: 'row',
    marginTop: 10,
    marginLeft: 10,
    marginBottom: 10
  },
  img: {
    width: 160,
    height: 120,
    borderRadius: 10
  },
  quick: {
    marginLeft: 15,
    fontSize: 16,
    fontWeight: 900,
    color: '#076CF2',
    marginTop: 20
  },
 
});
