import React, {useRef, useState} from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  ImageBackground,
  Image
} from 'react-native';
import CarouselCom from '../Subcomponent/Carousel';
import Img1 from '../../Videos/img1.jpg';
import Img2 from '../../Videos/img3.jpg';
import Img3 from '../../Videos/img3.jpg';
import Img4 from '../../Videos/img4.jpg';


const {width: windowWidth} = Dimensions.get('window');

const data = [
  {
    image: '../../Videos/img1.jpg',
    title: 'Lorem ipsum dolor sit amet',
    content:
      'Neque porro quisquam est qui ',
  },
  {
    uri: 'https://i.imgur.com/Pz2WYAc.jpg',
    title: 'Lorem ipsum ',
    content: 'Neque porro quisquam est qui dolorem ipsum ',
  },
  {
    uri: 'https://i.imgur.com/IGRuEAa.jpg',
    title: 'Lorem ipsum dolor',
    content:
      'Neque porro quisquam est qui dolorem',
  },
  {
    uri: 'https://i.imgur.com/fRGHItn.jpg',
    title: 'Lorem ipsum dolor',
    content: 'Neque porro quisquamt',
  },
  {
    uri: 'https://i.imgur.com/WmenvXr.jpg',
    title: 'Lorem ipsum ',
    content: 'Neque porro quisquam  ',
  },
];
export default function VideoCarousel(props) {
  return (
    <View>
    <Text style={{fontSize: 14, fontWeight: 900, marginLeft: 20, color: '#076CF2', marginBottom: 10 }}>Latest News Today </Text>
      
    </View>
  );
}

