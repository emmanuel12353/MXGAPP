import React, { memo } from 'react';


import Ionicons from '@expo/vector-icons/Ionicons';

import {
  Image,
  View,
  Row,
  Col,
  Text,
  StyleSheet,
  Pressable,
} from 'react-native';

const Quick = ({ navigation }) => (
  <>
    <Text style={{ marginLeft: 15, fontSize: 25 }}> Quick link </Text>
    <View
      style={{
        flexDirection: 'row',
        marginTop: 3,
        marginLeft: 15,
        marginBottom: 20,
      }}>
      <Pressable>
        <View
          style={{ backgroundColor: '#F0F0F0', margin: 10, borderRadius: 20 }}>
          <Ionicons name="bookmarks-sharp" style={{ margin: 30,
    color: '#510FE4',}} size={40} />
        </View>
        <Text style={{textAlign: 'center',}}>MXG Perks</Text>
      </Pressable>
      <View>
        <View
          style={{ backgroundColor: '#F0F0F0', margin: 10, borderRadius: 20 }}>
          <Ionicons name="document-text-sharp" style={{ margin: 30,
    color: '#510FE4',}} size={40} />
        </View>
        <Text style={{textAlign: 'center',}}>MXG Magazine</Text>
      </View>
      <View>
        <View
          style={{ backgroundColor: '#F0F0F0', margin: 10, borderRadius: 20 }}>
          <Ionicons name="videocam-sharp" style={{ margin: 30,
    color: '#510FE4',}} size={40} />
        </View>
        <Text style={{textAlign: 'center',}}>Markeying Video</Text>
      </View>
    </View>
    <View
      style={{
        flexDirection: 'row',
        marginTop: 5,
        marginLeft: 15,
        marginBottom: 50,
      }}>
      <View>
        <View style={{ backgroundColor: '#F0F0F0',
    margin: 10,
    borderRadius: 20,}}>
          <Ionicons name="videocam-sharp" style={{ margin: 30,
    color: '#510FE4',}} size={40} />
        </View>
        <Text style={{textAlign: 'center',}}>Resource Video</Text>
      </View>
      <View>
        <View style={{backgroundColor: '#F0F0F0',
    margin: 10,
    borderRadius: 20,}}>
          <Ionicons name="train-sharp" style={{ margin: 30,
    color: '#510FE4',}} size={40} />
        </View>
        <Text style={{textAlign: 'center'}}>News</Text>
      </View>
      <View>
        <View style={{backgroundColor: '#F0F0F0',
    margin: 10,
    borderRadius: 20,}}>
          <Ionicons name="calendar-sharp" style={{ margin: 30,
    color: '#510FE4',}} size={40} />
        </View>
        <Text style={{textAlign: 'center',}}>Calender</Text>
      </View>
    </View>
  </>
);

export default memo(Quick);
const styles = StyleSheet.create({

});
