import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { AdminDto } from 'src/Dto/adminDto';
import { Admin } from 'src/schemas/admin.schema';
import { User } from 'src/schemas/user.schema';
import { AdminType, UserType } from 'src/types';

@Injectable()
export class AdminService {
  constructor(
    @InjectModel(Admin.name) private adminModel: Model<Admin>,
    @InjectModel(User.name) private userModel: Model<User>,
  ) {}
  async findAdminLogin(email: string): Promise<Admin> {
    return this.adminModel.findOne({ email: email });
  }
  async createAdmin(user: AdminDto): Promise<Admin> {
    const createdAdmin = new this.adminModel({
      ...user,
      createdAt: new Date(),
    });
    return createdAdmin.save();
  }
  async getAllAdmins(): Promise<Admin[]> {
    return await this.adminModel.find();
  }
  async getAllUsers(): Promise<User[]> {
    return await this.userModel.find();
  }

  async getUserByEmail(user: UserType): Promise<User> {
    return await this.userModel.findOne({ email: user.email });
  }
  async getAdminByEmail(admin: AdminType): Promise<Admin> {
    return this.adminModel.findOne({ email: admin.email });
  }
  async updateAdmin(dataToUpdate: AdminType, user: AdminType): Promise<Admin> {
    const updatedUser = this.adminModel.findOneAndUpdate(
      { _id: user.userId },
      { ...dataToUpdate, updatedAt: new Date() },
      {
        returnOriginal: false,
      },
    );
    console.log(updatedUser, 'dataToUpdate');
    return updatedUser;
  }
  async deleteUser(user: UserType): Promise<User> {
    return this.userModel.findOneAndDelete(
      { email: user.email },
      { returnDocument: 'after' },
    );
  }
  async deleteAdmin(admin: AdminType): Promise<Admin> {
    return this.adminModel.findOneAndDelete(
      { email: admin.email },
      { returnDocument: 'after' },
    );
  }
}
