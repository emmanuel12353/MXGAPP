import { Module } from '@nestjs/common';
import { AdminService } from './admin.service';
import { UserSchema } from 'src/schemas/user.schema';
import { AdminSchema } from 'src/schemas/admin.schema';
import { MongooseModule } from '@nestjs/mongoose';
import { jwtConstants } from 'src/constants';
import { JwtModule } from '@nestjs/jwt';
import { JwtStrategy } from 'src/strategies/jwt.strategy';
import { UsersModule } from 'src/users/users.module';

@Module({
  providers: [AdminService],
  exports: [AdminService],
  imports: [
    MongooseModule.forFeature([{ name: 'User', schema: UserSchema }]),
    MongooseModule.forFeature([{ name: 'Admin', schema: AdminSchema }]),
  ],
})
export class AdminModule {}
