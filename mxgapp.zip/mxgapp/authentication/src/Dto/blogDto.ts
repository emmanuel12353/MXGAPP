export class BlogDto {
  createdAt: Date;
  content: string;
  title: string;
}
