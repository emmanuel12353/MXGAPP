export default {
  mongoUri: `mongodb+srv://olubobokun97:olubobokun97@cluster0.kt3zxvs.mongodb.net/testdb?retryWrites=true&w=majority`,
};
