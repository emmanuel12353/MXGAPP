import { v2 as cloudinary } from 'cloudinary';

export const CloudinaryProvider = {
  provide: 'CLOUDINARY',
  useFactory: () => {
    return cloudinary.config({
      cloud_name: 'debrain',
      api_key: '419267633286812',
      api_secret: 'JGQS6XMX4iAlqMlD7ZIqhUPItlA',
      asset_folder: 'authentiaction',
    });
  },
};
