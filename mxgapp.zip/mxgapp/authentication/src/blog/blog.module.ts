import { Module } from '@nestjs/common';
import { BlogService } from './blog.service';
import { MongooseModule } from '@nestjs/mongoose';
import { BlogSchema } from 'src/schemas/blogSchema';

@Module({
  providers: [BlogService],
  exports: [BlogService],
  imports: [MongooseModule.forFeature([{ name: 'Blog', schema: BlogSchema }])],
})
export class BlogModule {}
