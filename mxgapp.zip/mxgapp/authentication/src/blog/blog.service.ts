import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { Blog, BlogDocument } from 'src/schemas/blogSchema';
import { BlogType } from 'src/types';

@Injectable()
export class BlogService {
  constructor(
    @InjectModel(Blog.name) private readonly blogModel: Model<BlogDocument>,
  ) {}

  async createBlog(blog: BlogType): Promise<Blog> {
    const newBlog = new this.blogModel({
      ...blog,
      createdAt: new Date(),
    });
    return newBlog.save();
  }
  async getAllBlogs(): Promise<Blog[]> {
    return await this.blogModel.find();
  }
  async getBlogById(id: string): Promise<Blog> {
    return this.blogModel.findById(id);
  }

  async deleteBlogById(id: string): Promise<Blog> {
    return this.blogModel.findOneAndDelete(
      { _id: id },
      { returnDocument: 'after' },
    );
  }
}
