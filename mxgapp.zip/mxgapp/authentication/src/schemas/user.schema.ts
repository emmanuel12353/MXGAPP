import { Prop, Schema, SchemaFactory } from '@nestjs/mongoose';
import { HydratedDocument } from 'mongoose';

export type UserDocument = HydratedDocument<User>;

@Schema()
export class User {
  @Prop()
  fullName: string;

  @Prop()
  phoneNumber: string;

  @Prop()
  password: string;
  @Prop()
  email: string;
  @Prop()
  address: string;
  @Prop()
  location: string;
  @Prop()
  role: [string];
  @Prop()
  myInterest: string;
  @Prop()
  userId: string;
  @Prop()
  createdAt: Date;
  @Prop()
  updatedAt: Date;
  @Prop()
  image: string;
}

export const UserSchema = SchemaFactory.createForClass(User);
