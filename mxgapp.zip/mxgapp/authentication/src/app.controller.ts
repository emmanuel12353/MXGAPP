import {
  BadRequestException,
  Body,
  Controller,
  Delete,
  Get,
  Param,
  ParseFilePipeBuilder,
  Post,
  Put,
  Request,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from '@nestjs/common';
import { LocalAuthGuard } from './auth/guards/local-auth.guard';
import { AuthService } from './auth/auth.service';
import { JwtAuthGuard } from './auth/guards/jwt-auth.guard';

import { UsersService } from './users/users.service';
import { AuthGuard } from './auth/guards/auth.guard';
import { AdminService } from './admin/admin.service';
import { AdminAuthService } from './admin-auth/admin-auth.service';
import { AdminLocalAuthGuard } from './admin-auth/guards/admin-local-auth.guard';
import { RoleGuard } from './auth/role/role.guard';
import { Roles } from './auth/roles/roles.decorator';
import { Role } from './enums/role.enum';
import { FileInterceptor } from '@nestjs/platform-express';
import { FileService } from './file/file.service';
import { CloudinaryService } from './cloudinary/cloudinary.service';
import { imageFileFilter } from './file/imageFilter';
import { BlogDto } from './Dto/blogDto';
import { BlogService } from './blog/blog.service';
import { BlogType } from './types';

@Controller()
export class AppController {
  constructor(
    private readonly authService: AuthService,
    private readonly userService: UsersService,
    private readonly adminService: AdminService,
    private readonly adminAuthService: AdminAuthService,
    private readonly blogService: BlogService,
    private readonly cloudinaryService: CloudinaryService,
  ) {}

  @UseGuards(LocalAuthGuard)
  @Post('user/auth/login')
  async loginUser(@Request() req) {
    return await this.authService.login(req.user._doc);
  }

  @Post('user/auth/register')
  async registerUser(@Request() req) {
    return this.authService.registerUser(req.body);
  }
  // get user profile and admin profile
  @UseGuards(AuthGuard)
  @Get('auth/profile')
  getProfile(@Request() req) {
    return req.user;
  }

  @UseGuards(JwtAuthGuard)
  @Put('user/profile/update')
  async updateUser(@Request() req) {
    const updatedUser = await this.userService.updateUser(req.body, req.user);
    // strip password from user object
    const refreshToken = await this.authService.login(updatedUser);
    updatedUser.password = undefined;
    return {
      user: updatedUser,
      refreshToken,
    };
  }
  @UseGuards(JwtAuthGuard)
  @Post('admin/image/upload')
  @UseInterceptors(
    FileInterceptor('image', {
      fileFilter: imageFileFilter,
    }),
  )
  async uploadUserImage(
    @UploadedFile() file: Express.Multer.File,
    @Request() req,
  ) {
    const url = await this.cloudinaryService.uploadFile(file);
    if (!url) throw new BadRequestException('Error uploading image');
    const image = {
      image: url.secure_url,
    };
    const user = await this.userService.updateUser(image, req.user);
    const refreshToken = await this.authService.login(user);
    return {
      user,
      refreshToken,
    };
  }
  // admin routes
  // login admin
  @UseGuards(AdminLocalAuthGuard)
  @Post('admin/auth/login')
  async loginAdmin(@Request() req) {
    return await this.adminAuthService.login(req.user._doc);
  }
  // register admin
  @Post('admin/auth/register')
  async registerAdmin(@Request() req) {
    return this.adminAuthService.registerAdmin(req.body);
  }
  // get all users
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Get('admin/users')
  async getUsers() {
    return this.adminService.getAllUsers();
  }
  // get all admins
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Get('admin/admins')
  async getAdmins() {
    return await this.adminService.getAllAdmins();
  }
  // update admin profile
  @UseGuards(JwtAuthGuard)
  @Put('admin/profile/update')
  async updateAdmin(@Request() req) {
    const updatedUser = await this.adminService.updateAdmin(req.body, req.user);
    // strip password from user object
    const refreshToken = await this.adminAuthService.login(updatedUser);
    updatedUser.password = undefined;
    return {
      user: updatedUser,
      refreshToken,
    };
  }
  // admin image upload
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Post('admin/image/upload')
  @UseInterceptors(
    FileInterceptor('image', {
      fileFilter: imageFileFilter,
    }),
  )
  async uploadImage(@UploadedFile() file: Express.Multer.File, @Request() req) {
    const url = await this.cloudinaryService.uploadFile(file);
    if (!url) throw new BadRequestException('Error uploading image');
    const image = {
      image: url.secure_url,
    };
    const user = await this.adminService.updateAdmin(image, req.user);
    const refreshToken = await this.adminAuthService.login(user);
    return {
      user,
      refreshToken,
    };
  }

  // get user by email
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Post('admin/user/profile')
  async getUserByEmail(@Request() req) {
    return await this.adminService.getUserByEmail(req.body);
  }
  // get admin by email
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Post('admin/query/profile')
  async getAdminByEmail(@Request() req) {
    return await this.adminService.getAdminByEmail(req.body);
  }

  // delete user by email
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Delete('user/profile/delete')
  async deleteUser(@Request() req) {
    console.log(req, 'req.body');
    return await this.adminService.deleteUser(req.user);
  }
  // delete admin by email
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Delete('admin/profile/delete')
  async deleteAdmin(@Request() req) {
    return await this.adminService.deleteAdmin(req.user);
  }

  // blog upload routes
  // post blog
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Post('/blog/upload')
  @UseInterceptors(
    FileInterceptor('image', {
      fileFilter: imageFileFilter,
    }),
  )
  async uploadFile(
    @UploadedFile(
      new ParseFilePipeBuilder()
        .addMaxSizeValidator({
          maxSize: 1024 * 1024 * 5,
          message: 'File too large',
        })
        .build({
          errorHttpStatusCode: 400,
        }),
    )
    file: Express.Multer.File,
    @Body() blogDto: BlogDto,
    @Request() req,
  ) {
    const url = await this.cloudinaryService.uploadFile(file);
    if (!url) throw new BadRequestException('Error uploading file');
    const datas: BlogType = {
      ...blogDto,
      image: url.secure_url,
      adminName: req.user.name,
    };
    return await this.blogService.createBlog(datas);
  }
  // get all blogs

  @Get('/blogs')
  async getBlogs() {
    return await this.blogService.getAllBlogs();
  }
  // get blog by id
  @Get('/blog/:id')
  async getBlogById(@Param('id') id: string) {
    return await this.blogService.getBlogById(id);
  }
  // delete blog by id
  @Roles(Role.Admin)
  @UseGuards(JwtAuthGuard, RoleGuard)
  @Delete('/blog/:id')
  async deleteBlogById(@Param('id') id: string) {
    return await this.blogService.deleteBlogById(id);
  }
}
