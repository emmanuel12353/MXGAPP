import { Injectable, UnauthorizedException } from '@nestjs/common';
import { UsersService } from 'src/users/users.service';
import { JwtService } from '@nestjs/jwt';
import { UserDto } from 'src/Dto/userDto';
import * as bcrypt from 'bcrypt';
import { UserType } from 'src/types';

@Injectable()
export class AuthService {
  constructor(
    private usersService: UsersService,
    private jwtService: JwtService,
  ) {}

  async validateUser(email: string, pass: string): Promise<UserType> {
    const user = await this.usersService.findUserLogin(email);
    if (user) {
      if (!bcrypt.compareSync(pass, user.password)) {
        throw new UnauthorizedException('Invalid password');
      }
      const { password, ...result } = user;
      return result;
    }
    throw new UnauthorizedException('User does not exist');
  }

  async registerUser(user: UserDto) {
    const userObj = await this.usersService.findUserLogin(user.email);
    if (userObj) {
      throw new UnauthorizedException('User already exist');
    }
    if (user.role[0] !== 'user') {
      return new UnauthorizedException(
        "You can't register as Admin, contact your organization for registration",
      );
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(user.password, salt);
    user.password = hashedPassword;
    return this.usersService.createUser(user);
  }

  async login(user: any) {
    const payload = {
      email: user.email,
      sub: user._id,
      role: user.role,
      fullName: user.fullName,
      address: user.address,
      phoneNumber: user.phoneNumber,
      location: user.location,
      myInterest: user.myInterest,
      createdAt: user.createdAt,
      image: user.image,
    };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}
