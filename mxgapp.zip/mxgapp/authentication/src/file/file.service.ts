import { HttpService } from '@nestjs/axios';
import { Injectable } from '@nestjs/common';
import { AxiosError } from 'axios';
import { catchError, firstValueFrom } from 'rxjs';

@Injectable()
export class FileService {
  // eslint-disable-next-line prettier/prettier
  constructor(private httpService: HttpService) {}

  async uploadFile(file: Express.Multer.File) {
    const formData = new FormData();
    formData.append('file', file.buffer.toString('base64'));
    formData.append('upload_preset', 'ml_default');
    formData.append('public_id', 'hello');
    formData.append('api_key', '419267633286812');
    const { data } = await firstValueFrom(
      this.httpService
        .post('https://api.cloudinary.com/v1_1/debrain/image/upload', formData)
        .pipe(
          catchError((error: AxiosError) => {
            console.log(error.response.data, 'error');
            throw error;
          }),
        ),
    );
    return data;
  }
}
