import { Document } from 'mongoose';

export interface UserType {
  fullName?: string;
  email?: string;
  password?: string;
  role?: [string];
  myInterest?: string;
  userId?: string;
  createdAt?: Date;
  updatedAt?: Date;
  address?: string;
  phoneNumber?: string;
  location?: string;
  image?: string;
}

export interface AdminType {
  fullName?: string;
  email?: string;
  password?: string;
  role?: [string];
  myInterest?: string;
  userId?: string;
  createdAt?: Date;
  updatedAt?: Date;
  address?: string;
  phoneNumber?: string;
  location?: string;
  image?: string;
}
export interface BlogType {
  title: string;
  content: string;
  createdAt?: Date;
  image?: string;
  adminName: string;
}
