import { Strategy } from 'passport-local';
import { PassportStrategy } from '@nestjs/passport';
import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AdminType } from 'src/types';
import { AdminAuthService } from 'src/admin-auth/admin-auth.service';

@Injectable()
export class LocalStrategy extends PassportStrategy(Strategy, 'admin') {
  constructor(private adminAuthService: AdminAuthService) {
    super({
      usernameField: 'email',
    });
  }

  async validate(email: string, password: string): Promise<AdminType> {
    const admin = await this.adminAuthService.validateAdmin(email, password);
    if (!admin) {
      throw new UnauthorizedException();
    }
    return admin;
  }
}
