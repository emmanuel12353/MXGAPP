import { Injectable, UnauthorizedException } from '@nestjs/common';
import { AdminService } from 'src/admin/admin.service';
import { AdminType } from 'src/types';
import * as bcrypt from 'bcrypt';
import { AdminDto } from 'src/Dto/adminDto';
import { JwtService } from '@nestjs/jwt';

@Injectable()
export class AdminAuthService {
  constructor(
    private adminService: AdminService,
    private jwtService: JwtService,
  ) {}
  async validateAdmin(email: string, pass: string): Promise<AdminType> {
    const admin = await this.adminService.findAdminLogin(email);
    console.log(admin, 'admin in auth service');
    if (admin) {
      if (!bcrypt.compareSync(pass, admin.password)) {
        throw new UnauthorizedException('Invalid password');
      }
      const { password, ...result } = admin;
      return result;
    }
    throw new UnauthorizedException('Admin does not exist');
  }
  async registerAdmin(user: AdminDto) {
    const userObj = await this.adminService.findAdminLogin(user.email);
    if (userObj) {
      throw new UnauthorizedException(
        'User already exist , kindly create new account with another email',
      );
    }
    if (user.role[0] !== 'admin') {
      return new UnauthorizedException(
        "You can't register as admin, contact your organization for registration",
      );
    }
    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(user.password, salt);
    user.password = hashedPassword;
    return this.adminService.createAdmin(user);
  }
  async login(user: any) {
    const payload = {
      email: user.email,
      sub: user._id,
      role: user.role,
      fullName: user.fullName,
      address: user.address,
      phoneNumber: user.phoneNumber,
      location: user.location,
      myInterest: user.myInterest,
      createdAt: user.createdAt,
      image: user.image,
    };
    return {
      access_token: this.jwtService.sign(payload),
    };
  }
}
