import { Module } from '@nestjs/common';
import { AdminAuthService } from './admin-auth.service';
import { AdminModule } from 'src/admin/admin.module';
import { JwtModule } from '@nestjs/jwt';
import { jwtConstants } from 'src/constants';
import { JwtStrategy } from 'src/strategies/jwt.strategy';
import { PassportModule } from '@nestjs/passport';
import { LocalStrategy } from './local.strategy';
import { AuthModule } from 'src/auth/auth.module';

@Module({
  providers: [AdminAuthService, LocalStrategy, JwtStrategy],
  exports: [AdminAuthService],
  imports: [
    AdminModule,
    PassportModule,
    AuthModule,
    JwtModule.register({
      secret: jwtConstants.secret,
      signOptions: { expiresIn: '1h' },
    }),
  ],
})
export class AdminAuthModule {}
