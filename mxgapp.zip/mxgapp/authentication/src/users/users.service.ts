import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { UserDto } from 'src/Dto/userDto';
import { User } from 'src/schemas/user.schema';
import { UserType } from 'src/types';

@Injectable()
export class UsersService {
  constructor(@InjectModel(User.name) private userModel: Model<User>) {}

  async findUserLogin(email: string): Promise<User> {
    return this.userModel.findOne({ email: email });
  }

  async createUser(user: UserDto): Promise<User> {
    const createdUser = new this.userModel({ ...user, createdAt: new Date() });
    return createdUser.save();
  }

  async getUserById(id: string): Promise<User> {
    return this.userModel.findById(id);
  }

  async updateUser(dataToUpdate: UserType, user: UserType): Promise<User> {
    const updatedUser = this.userModel.findOneAndUpdate(
      { _id: user.userId },
      { ...dataToUpdate, updatedAt: new Date() },
      {
        returnOriginal: false,
      },
    );
    console.log(updatedUser, 'dataToUpdate');
    return updatedUser;
  }
}
